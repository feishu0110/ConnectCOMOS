﻿
Class MainWindow
    '{3BDD1BA3-E09C-11CF-9BB7-00A0248A9BEE} 
    Private Sub ConnectCOMOS_Click(sender As Object, e As RoutedEventArgs) Handles ConnectCOMOS.Click
        Dim CurUser As Plt.IComosDUser
        Dim DBPath As String
        Dim Workset As Plt.IComosDWorkset
        Workset = Nothing

        If (Comos.Global.AppGlobal.Workset Is Nothing) Then
            Workset = New Plt.CPLTWorksetClass
            If Not Workset Is Nothing Then
                Comos.Global.AppGlobal.Workset = Workset
            End If
        End If


        DBPath = txtDBPath.Text

        'check if a path has been entered
        If DBPath = "" Then
            MsgBox（"请输入本地数据库地址!", 64, "提示")
            Exit Sub
        End If
        'Start instance of Comos
        'Try to open the database
        Dim msgErr As Boolean

        If (Not Workset.IsInitialized()) Then
            msgErr = Workset.Init(String.Empty, String.Empty, DBPath)


            If (Not Comos.Global.AppGlobal.Workset.IsInitialized()) Then

                msgErr = True

            Else

                msgErr = False

            End If

        End If

        'If Not Workset.Init(String.Empty, String.Empty, DBPath) And Not Workset.IsInitialized() Then

        If msgErr = True Then

            '    MsgBox("无法打开数据库:  " + vbCrLf + DBPath, 64, "提示")
            '    Exit Sub
        End If

        ' the setup user
        CurUser = Workset.GetAllUsers.Item("@SETUP")
        'Safety check if user exists or not
        If CurUser Is Nothing Then
            MsgBox（"用户 '@Setup' 不存在." + vbCrLf + DBPath, vbCritical + vbOKOnly)

            Exit Sub
        End If
        'Set user
        Workset.SetCurrentUser(CurUser)
        'get project
        Dim PrjCol As Plt.IComosDCollection
        Dim Proj As Plt.IComosDProject
        Dim strMsgInfo As String
        strMsgInfo = ""
        PrjCol = Workset.GetAllProjects
        For i = 1 To PrjCol.Count
            Proj = Workset.GetAllProjects.Item(i)
            strMsgInfo += Proj.Name + Proj.Description + vbCrLf
        Next
        txtMsgInfo.Text = strMsgInfo




    End Sub

End Class

